
<div class="container-fluid bg-dark text-light footer wow fadeIn" data-wow-delay="0.1s">
      <div class="container pb-5">
          <div class="row g-5">
              <div class="col-md-6 col-lg-4">
                  <div class="bg-primary rounded p-4">
                  <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d112272.66743156468!2d79.35395135662893!3d28.43371123968163!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39a0093f6a8d1ecd%3A0x7056633d94da87ba!2sSRMS%20COLLEGE%20OF%20ENGINEERING%20%26%20TECHNOLOGY%2C%20BAREILLY!5e0!3m2!1sen!2sin!4v1681563033694!5m2!1sen!2sin" width="400" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                  </div>
              </div>
              <div class="col-md-6 col-lg-8 text-center">
                  <h3 class="section-title  text-primary text-uppercase mb-4"style="text-decoration:underline">Contact</h6>
                  <p class="mb-2"><i class="fa fa-map-marker-alt me-4"></i>SRMS COLLEGE OF ENGINEERING & TECHNOLOGY</p>
                  <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>Ram Murti Puram 13 KM Bareilly-Nainital Road<br>
                  Bhojipura, Bareilly<br>Uttar Pradesh 243202</p>
                  <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>http://www.srms.ac.in/cet/</p>
                  <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>07900553000</p>
                  <p class="mb-2"><i class="fa fa-envelope me-3"></i>cet@srmscet.edu</p>
                  <!-- <div class="d-flex pt-2 text-center">
                      <a class="btn btn-outline-light btn-social text-center" href=""><i class="fab fa-twitter"></i></a>
                      <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-facebook-f"></i></a>
                      <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-youtube"></i></a>
                      <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-linkedin-in"></i></a>
                  </div> -->
              </div>
              
          </div>
      </div>
  </div>
       <!-- Bootstrap core JavaScript -->
       <script src="assets/plugins/jquery/jquery.min.js"></script>
    <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="assets/plugins/jquery-easing/jquery.easing.min.js"></script>

    <!-- Contact form JavaScript -->
    <script src="assets/js/jqBootstrapValidation.js"></script>
    <script src="assets/js/contact_me.js"></script>

    <!-- Custom scripts for this template -->
    <script src="assets/js/rent.js"></script>
  </body>
</html>