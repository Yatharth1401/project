<?php
error_reporting(0);
  require 'config/config.php';
  if ($_SERVER['REQUEST_METHOD'] == "POST") {
      $location = $_POST['location'];
      $bhk = $_POST['bhk'];
      $area = $_POST['area'];
      $bathroom = $_POST['bathroom'];
      
      $sql1 = mysqli_query($conn,"SELECT * FROM location where  size = '".$bhk."' AND total_sqft = '".$area."'");
      $res1 = mysqli_fetch_assoc($sql1);

    
  }
?>





<?php require 'includes/head.php' ?>

<body>
  <?php require 'includes/navbar.php' ?>



  <!-- Search -->
  <section id="search">
    <div class="container ">
      <h2 class="section-heading text-uppercase text-center">HOUSE PRICE PREDICTION</h2>
      <div class="row">
        <div class="col-lg-12 text-center">
          <!-- <h2 class="section-heading text-uppercase">Search</h2> -->
          <h3 class="section-subheading text-muted">Search rooms or homes for hire.</h3>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <form method="POST" class="center">
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <label for="location" class="text-start">Location</label>
                  <?php 
                      $res = mysqli_query($conn,"SELECT * FROM location");                        
                      ?>
                  <select class="form-select form-control" name="location" aria-label="Default select example">
                    <option value="" disabled selected>SELECT LOCATION</option>
                    <?php
                      while ($location_data = mysqli_fetch_assoc($res)) {
                      ?>
                    <option value="<?php $location_data['Location']?>"><?php echo $location_data['Location'] ?></option>
                    <?php
                      }
                    ?>
                  </select>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label for="bhk" class="text-start">BHK</label>
                  <input class="form-control" id="bhk" name="bhk" type="text" placeholder="Enter bhk(Ex: 1bhk,rent..)"
                    required data-validation-required-message="Please enter keywords">
                  <small>Example : 1 Bhk</small>
                </div>
              </div>

              <div class="col-md-6">
                <div class="form-group">
                  <label for="area" class="text-start">Area</label>
                  <input class="form-control" id="area" type="text" name="area" placeholder="Enter Area" required
                    data-validation-required-message="Please enter location.">
                  <p class="help-block text-danger"></p>
                </div>
              </div>

              <div class="col-md-6">
                <div class="form-group">
                  <label for="bathroom" class="text-start">Bathroom</label>
                  <input class="form-control" id="bathroom" type="text" name="bathroom" placeholder="Enter Bathroom"
                    required data-validation-required-message="Please enter location.">
                  <p class="help-block text-danger"></p>
                </div>
              </div>

              <div class="col-md-12 text-center">
                <div class="form-group">
                  <button id="" class="btn btn-success btn-md text-uppercase" type="submit">Search</button>
                </div>
              </div>
            </div>
          </form>

        </div>
      </div>
    </div>
  </section>
  <div class="text-center wow fadeInUp mb-5" data-wow-delay="0.1s">
    <h1 class=""><span class="text-primary text-uppercase">Average Cost</span></h1>
    <h6 class="section-title text-center text-primary text-dark text-uppercase">23Lakh</h6>
      </div>
  <!-- Room Start -->
  <div class="container-xxl">
    <div class="container">
      <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
        <h6 class="section-title text-center text-primary text-uppercase">Our Rooms</h6>
        <h1 class="mb-5">Explore Our <span class="text-primary text-uppercase">Rooms</span></h1>
        <p><?php
        echo "Avg";
        $avg = mysqli_num_rows($res) ; 
        echo $avg;?></p>
      </div>
      <div class="row g-4">
        <?php
            if (mysqli_num_rows($res)>0) {
              while ($res1 = mysqli_fetch_assoc($sql1)) {
                echo '<div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                <div class="room-item shadow rounded overflow-hidden">
                    <div class="position-relative">
                        <img class="img-fluid" src="./imgs/room-1.jpg" alt="">
                        <small class="position-absolute start-0 top-100 translate-middle-y bg-primary text-white rounded py-1 px-3 ms-4"> Rs '.$res1['price'].' Lakh</small>
                    </div>
                    <div class="p-4 mt-2">
                        <div class="d-flex justify-content-between mb-3">
                            <h5 class="mb-0">'.$res1['Location'].'</h5>
                            <div class="ps-2">
                                <small class="fa fa-star text-primary"></small>
                                <small class="fa fa-star text-primary"></small>
                                <small class="fa fa-star text-primary"></small>
                                <small class="fa fa-star text-primary"></small>
                                <small class="fa fa-star text-primary"></small>
                            </div>
                        </div>
                        <div class="d-flex mb-3">
                            <small class="border-end me-3 pe-3"><i class="fa fa-bed text-primary me-2"></i>'.$res1['size'].'</small>
                            <small class="border-end me-3 pe-3"><i class="fa fa-bath text-primary me-2"></i>'.$res1['bath'].' Bath</small>
                            <small><i class="fa fa-wifi text-primary me-2"></i>Wifi</small>
                        </div>
                        <table class="table text-start">
                          <tbody>
                            <tr>
                              <td>Area</td>
                              <td>'.$res1['total_sqft'].'</td>
                            </tr>
                            <tr>
                              <td>Area Type</td>
                              <td>'.$res1['area_type'].'</td>
                            </tr>
                            <tr>
                              <td>Availability</td>
                              <td>'.$res1['availability'].'</td>
                            </tr>
                            <tr>
                              <td>Society</td>
                              <td>'.$res1['society'].'</td>
                            </tr> 
                          </tbody>
                        </table>
                        <p class="text-body mb-3">.</p>
                        <div class="text-center ">
                            <a class="btn btn-sm btn-warning rounded py-2 px-4 text-white " href="">Book Now</a>
                        </div>
                    </div>
                </div>
            </div>';
              }
            }
          ?>
        
      </div>
    </div>
  </div>
</body>