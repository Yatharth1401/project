<!-- <div class="row"> -->			
  <div class="col-md-11 col-xs-12 col-sm-12">
  	<div class="alert alert-info" role="alert">
  		<?php
			if(isset($errMsg)){
				echo '<div style="color:#FF0000;text-align:center;font-size:17px;">'.$errMsg.'</div>';
			}
		?>
  		<h2 class="text-center text-uppercase">Registration</h2>
  		<form action="" method="post" enctype="multipart/form-data">
	

			<div class="row">
		  	
				 <div class="col-md-4">
				  <div class="form-group">
				    <label for="email">Location</label>
				    <input type="text" class="form-control"  placeholder="Location" name="location" required>
				  </div>
				 </div>
				 <div class="col-md-4">
				  <div class="form-group">
				    <label for="email">BHK</label>
				    <input type="bhk" class="form-control"  placeholder="Bhk" name="bhk" required>
					  
				</div>
				 </div>
				 <div class="col-md-4">
				  <div class="form-group">
				    <label for="email">Area</label>
				    <input type="text" class="form-control"  placeholder="Area" name="area" required>
				  </div>
				 </div>
				 <div class="col-md-4">
				  <div class="form-group">
				    <label for="email">Area Type</label>
				    <input type="int" class="form-control"  placeholder="Area" name="area_type" required>
				  </div>
				 </div>
				 <div class="col-md-4">
				  <div class="form-group">
				    <label for="email">Availability</label>
				    <input type="text" class="form-control"  placeholder="Availability" name="availability" required>
				  </div>
				 </div>
				 <div class="col-md-4">
				  <div class="form-group">
				    <label for="email">Society</label>
				    <input type="text" class="form-control"  placeholder="Society" name="society" required>
					</div>
				 </div>
				 <div class="col-md-4">
				  <div class="form-group">
				    <label for="email">Balcony</label>
				    <input type="text" class="form-control"  placeholder="Balcony" name="balcony" required>
					</div>
				 </div>
				 <div class="col-md-4">
				  <div class="form-group">
				    <label for="email">Bathroom</label>
				    <input type="text" class="form-control"  placeholder="Bathroom" name="bathroom" required>
					</div>
				 </div>
				 <div class="col-md-4">
				  <div class="form-group">
				    <label for="email">Price</label>
				    <input type="text" class="form-control"  placeholder="Price" name="price" required>
					</div>
				 </div>

				 
			</div>			  
		   <div class="row">
		   	<div class="col-4">		 
			 	</div>
				<!-- <div class="col-md-4">
					<div class="form-group">
						<label for="description">Image</label>
						<input type="file" name="image" id="image">
					</div>
			  </div> -->
			  </div>			
			  <button type="submit" class="btn btn-primary" name='register_individuals' value="register_individuals">Submit</button>
			</form>	
			</div>			
  	</div>
<!-- </div> -->