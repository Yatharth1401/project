<?php
	require '../../config/config.php';
$del = mysqli_query($conn,"DELETE FROM location WHERE id = '".$_GET['del_id']."'");
if ($del) {
   header("Location:../list.php");
} else {
   echo "Error";
}

?>